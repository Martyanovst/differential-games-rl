import sys

import numpy as np
import torch

from gfootball.env.wrappers import Simple115StateWrapper
from torch import nn

sys.path.append('/kaggle_simulations/agent/')


class Seq_Network(nn.Module):
    def __init__(self, layers, hidden_activation, output_activation=None):
        super().__init__()
        hidden_layers = layers[:-1]
        network = [nn.Sequential(nn.Linear(i, o), hidden_activation) for i, o in
                   zip(hidden_layers, hidden_layers[1:])]
        network.append(nn.Linear(layers[-2], layers[-1]))
        if output_activation:
            network.append(output_activation)
        self.network = nn.Sequential(*network)
        self.apply(self._init_weights_)

    def forward(self, tensor):
        return self.network(tensor)

    def _init_weights_(self, m):
        if type(m) == nn.Linear:
            torch.nn.init.xavier_normal_(m.weight)
            m.bias.data.fill_(0.01)


action_model = Seq_Network([115, 80, 40, 19], nn.ReLU())
action_model.load_state_dict(torch.load('/kaggle_simulations/agent/weights'))


def agent(obs):
    # Convert these to the same output as the Simple115StateWrapper we used in training
    obs = Simple115StateWrapper.convert_observation(obs['players_raw'], fixed_positions=False)

    # Predict actions from keras model
    state = torch.tensor(obs, dtype=torch.float)
    qvalues = action_model(state).data.numpy()
    action = np.argmax(qvalues)
    print(action)
    return [1]
